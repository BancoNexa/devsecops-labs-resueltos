
// logs_INSEGURO.dart
void processPayment(String cardNumber, String cvv) {
  // ❌ Nunca imprimir datos de tarjeta o CVV
  print("Procesando tarjeta: $cardNumber con CVV $cvv"); 
}
